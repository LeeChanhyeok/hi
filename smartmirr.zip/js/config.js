var FORCAST_API_KEY = "9320802dea1ed6f6ab7f466d781e9588";
var HUE_BASE = "http://{IP_ADDRESS_OF_BRIDGE}/api/{Username}/";
var PERSONAL_CALENDAR = [];
